# Azure Core AMQP shared client library for .NET

Azure.Core.Amqp contains AMQP primitives.
